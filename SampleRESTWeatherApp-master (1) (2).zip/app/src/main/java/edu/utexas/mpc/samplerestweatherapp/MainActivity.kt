package edu.utexas.mpc.samplerestweatherapp

import android.content.DialogInterface
import android.content.Intent
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import com.android.volley.RequestQueue
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import com.google.gson.Gson
import kotlinx.android.synthetic.main.activity_main.*
import android.support.v4.app.SupportActivity
import android.support.v4.app.SupportActivity.ExtraData
import android.support.v4.content.ContextCompat.getSystemService
import android.icu.lang.UCharacter.GraphemeClusterBreak.T
import android.media.MediaMetadataRetriever
import android.provider.Settings
import android.support.v7.app.AlertDialog
import android.view.View
import android.widget.*
import com.google.gson.annotations.SerializedName
import com.shuhart.materialcalendarview.CalendarDay
import com.shuhart.materialcalendarview.MaterialCalendarView
import com.squareup.picasso.Picasso
import org.eclipse.paho.android.service.MqttAndroidClient
import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken
import org.eclipse.paho.client.mqttv3.MqttCallbackExtended
import org.eclipse.paho.client.mqttv3.MqttMessage
import java.lang.NullPointerException
import java.time.LocalDate
import java.time.LocalTime

import java.util.*
import kotlin.collections.HashSet

class MainActivity : AppCompatActivity() {


    // I'm using lateinit for these widgets because I read that repeated calls to findViewById
    // are energy intensive
    lateinit var textView: TextView
    lateinit var mainView: TextView
    lateinit var curtempmaxView: TextView
    lateinit var curtempminView: TextView
    lateinit var currainView: TextView
    lateinit var nexttempmaxView: TextView
    lateinit var nexttempminView: TextView
    lateinit var nextrainView: TextView
    lateinit var imageView: ImageView
    lateinit var retrieveButton: Button
    //lateinit var currentButton: Button
    //lateinit var forecastButton: Button
    lateinit var sendButton: Button
    lateinit var cityText: EditText

    lateinit var queue: RequestQueue
    lateinit var gson: Gson
    lateinit var mostRecentWeatherResult: WeatherResult
    lateinit var forecastWeatherResult: ForecastResult
    // I'm using lateinit for these widgets because I read that repeated calls to findViewById
    // are energy intensive
    lateinit var stepsView: TextView
    lateinit var tableLayout: TableLayout
    lateinit var syncButton: Button
    lateinit var calendarView: MaterialCalendarView

    // I'm doing a late init here because I need this to be an instance variable but I don't
    // have all the info I need to initialize it yet
    lateinit var mqttAndroidClient: MqttAndroidClient

    // you may need to change this depending on where your MQTT broker is running
    val serverUri = "tcp://192.168.4.1:1883"
    // you can use whatever name you want to here
    val clientId = "EmergingTechMQTTClient"

    //these should "match" the topics on the "other side" (i.e, on the Raspberry Pi)
    val subscribeTopic = "ssy_steps"
    val publishTopic = "ssy_weather"
    val testTopic = "ssy_connection"
    var forecastmax: Double = 0.0
    var forecastmin = 0.0
    var forecastrain = 0.0
    var cur_max = 0.0
    var cur_min = 0.0
    var pre = "0"
    var description = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        textView = this.findViewById(R.id.text)
        syncButton = this.findViewById(R.id.syncButton)
        sendButton = this.findViewById(R.id.sendButton)
        cityText = this.findViewById(R.id.input_city)
        tableLayout = this.findViewById(R.id.details)

        // when the user presses the syncbutton, this method will get called
        syncButton.setOnClickListener({ syncWithPi() })
        sendButton.setOnClickListener({sendWeather()})

        // initialize the paho mqtt client with the uri and client id
        mqttAndroidClient = MqttAndroidClient(getApplicationContext(), serverUri, clientId)
        stepsView = this.findViewById(R.id.steps)
        mainView = this.findViewById(R.id.main)
        curtempmaxView = this.findViewById(R.id.cur_temp_max)
        curtempminView = this.findViewById(R.id.cur_temp_min)
        currainView = this.findViewById(R.id.cur_rain)
        nexttempmaxView = this.findViewById(R.id.for_temp_max)
        nexttempminView = this.findViewById(R.id.for_temp_min)
        nextrainView = this.findViewById(R.id.for_rain)
        imageView = this.findViewById(R.id.weathericon)
        retrieveButton = this.findViewById(R.id.retrieveButton)
        calendarView = this.findViewById(R.id.goals)
        //currentButton = this.findViewById(R.id.currentButton)
        //forecastButton = this.findViewById(R.id.forecastButton)

        // when the user presses the currentbutton, this method will get called
        retrieveButton.setOnClickListener({ requestCurrentWeather() })

        queue = Volley.newRequestQueue(this)
        gson = Gson()

        // Calendar stuff



        // when things happen in the mqtt client, these callbacks will be called
        mqttAndroidClient.setCallback(object: MqttCallbackExtended {

            // when the client is successfully connected to the broker, this method gets called
            override fun connectComplete(reconnect: Boolean, serverURI: String?) {
                println("Connection Complete!!")
            }

            // this method is called when a message is received that fulfills a subscription
            override fun messageArrived(topic: String?, message: MqttMessage?) {
                println(message)
                if (message != null){
                    stepsView.text = message.toString()
                }

            }

            override fun connectionLost(cause: Throwable?) {
                println("Connection Lost")
            }

            // this method is called when the client succcessfully publishes to the broker
            override fun deliveryComplete(token: IMqttDeliveryToken?) {
                println("Delivery Complete")
            }
        })

    }


    private fun piConnectionTest(){
        // this subscribes the client to the subscribe topic
        try{
            mqttAndroidClient.subscribe(testTopic, 0)
            stepsView.text = "Connection Success."
        }
        catch (error: NullPointerException){
            stepsView.text = "Connection Failed."
        }

    }
    // this method just connects the paho mqtt client to the broker
    private fun connectToPi(){
        println("+++++++ Connecting...")
        mqttAndroidClient.connect()
        stepsView.text = "Connecting to the Pi..."
        piConnectionTest()
    }

    private fun syncWithPi() {
        val url = StringBuilder("https://www.google.com").toString()
        val stringRequest = object : StringRequest(Method.GET, url,
                com.android.volley.Response.Listener<String> { _ ->
                    // Show Alert
                    val dialogBuilder = AlertDialog.Builder(this)
                    dialogBuilder.setMessage("Switch to Raspberry Pi Network!")
                            .setCancelable(false)
                            .setPositiveButton("Switch", DialogInterface.OnClickListener({
                                dialog, _->dialog.cancel()
                                println("--------Switching Network Setting--------")
                                startActivity(Intent(Settings.ACTION_WIFI_SETTINGS))
                            }))
                            .setNegativeButton("Cancel", DialogInterface.OnClickListener({
                                dialog, _->dialog.cancel()
                            }))
                    val alert = dialogBuilder.create()
                    alert.setTitle("Network Switch")
                    alert.show()
                    // Switch to Network setting page
                },
                com.android.volley.Response.ErrorListener {
                    connectToPi()
                }) {}
        queue.add(stringRequest)
        connectToPi()
    }

    private fun sendWeather(){
        // this subscribes the client to the subscribe topic
        try {
            mqttAndroidClient.subscribe(subscribeTopic, 0)
            val message = MqttMessage()
            message.payload = ("Main:$description?CurMaxTemp:$cur_max?CurMinTemp:$cur_min?CurRain:$pre?NextMaxTemp:$forecastmax?NextMinTemp:$forecastmin?NextRain:$forecastrain").toByteArray()
            println("Sending message: Main:$description?CurMaxTemp:$cur_max?CurMinTemp:$cur_min?CurRain:$pre?NextMaxTemp:$forecastmax?NextMinTemp:$forecastmin?NextRain:$forecastrain")
            stepsView.text = "Weather Sent."
            // this publishes a message to the publish topic
            mqttAndroidClient.publish(publishTopic, message)
            println("Finish sending")
        }
        catch(error: NullPointerException){
            stepsView.text = "Not Connected to the Pi."
        }

    }

    private fun requestCurrentWeather(){
        val requestCityName = cityText.text
        stepsView.text = ""
        println("Request City Name: $requestCityName")
        // Current weather
        val url = StringBuilder("https://api.openweathermap.org/data/2.5/weather?q=$requestCityName&appid=424d1ce6a52839be522ab49c360a70df&units=imperial").toString()
        val url1 = StringBuilder("https://api.openweathermap.org/data/2.5/forecast?q=$requestCityName&appid=424d1ce6a52839be522ab49c360a70df&units=imperial").toString()

        println("RESTful request: $url")
        cur_max = 0.0
        cur_min = 0.0
        val stringRequest = object : StringRequest(Method.GET, url,
                com.android.volley.Response.Listener<String> { response ->
                    println("response: $response")
                    val rawdata = response.toString()
                    val pattern = "\"rain\":(.+)".toRegex()
                    val matches = pattern.findAll(rawdata)

                    val result = matches.map { it.groupValues[1] }.joinToString()
                    println("result: $result")
                    println("First split: "+result.split(",")[0])
                    pre = "0"
                    if (result.isNotEmpty()) {
                        pre = result.split(",")[0].split(":")[1].split("}")[0]
                        println("Pre: $pre")
                    }
                    mostRecentWeatherResult = gson.fromJson(response, WeatherResult::class.java)
                    description = mostRecentWeatherResult.weather.get(0).main
                    mainView.text = description
                    //println("Main Weather for today: ${mostRecentWeatherResult.weather.get(0).main}")
                    cur_max = mostRecentWeatherResult.main.temp_max
                    cur_min = mostRecentWeatherResult.main.temp_min
                    //curtempmaxView.text = mostRecentWeatherResult.main.temp_max.toString()
                    //curtempminView.text = mostRecentWeatherResult.main.temp_min.toString()
                    val iconCode = mostRecentWeatherResult.weather.get(0).icon
                    currainView.text = pre

                    val iconUrl = "https://openweathermap.org/img/wn/$iconCode@2x.png"
                    println(iconUrl)
                    Picasso.get().load(iconUrl).into(imageView)
                    tableLayout.visibility = View.VISIBLE
                },
                com.android.volley.Response.ErrorListener {
                    println("******That didn't work!")
                    mainView.text = "Network Failure or City Not Exists"
                    curtempmaxView.text = ""
                    curtempminView.text = ""
                    currainView.text = ""
                }) {}
        val stringRequest1 = object : StringRequest(Method.GET, url1,
                com.android.volley.Response.Listener<String> { response ->
                    println("Forecast response: $response")
                    forecastWeatherResult = gson.fromJson(response, ForecastResult::class.java)
                    forecastmax = -100.0
                    forecastmin = 200.0
                    forecastrain = 0.0
                    var temp1: Double
                    var temp2: Double
                    var datetime: String
                    var timezone: Int = ((-forecastWeatherResult.city.timezone/3600)/3).toInt()*3

                    var temp_count = 0
                    for (i in 0 until 40){
                        temp1 = forecastWeatherResult.list.get(i).main.temp_max
                        temp2 = forecastWeatherResult.list.get(i).main.temp_min
                        datetime = forecastWeatherResult.list.get(i).dt_txt
                        if (datetime.split(" ")[1].split(":")[0].toInt() != timezone){
                            // the dt_txt time is UTC.
                            if (temp1 > cur_max) cur_max = temp1
                            if (temp2 < cur_min) cur_min = temp2
                        }
                        else {
                            if (temp_count > 8) break
                            if (forecastmax < temp1)
                                forecastmax = temp1

                            if (forecastmin > temp2)
                                forecastmin = temp2
                            try {
                                forecastrain += forecastWeatherResult.list.get(i).rain.threehour!!
                            } catch (error: NullPointerException) {
                                continue
                            }
                            temp_count += 1
                        }
                    }
                    nexttempminView.text = forecastmin.toString()
                    nexttempmaxView.text = forecastmax.toString()
                    nextrainView.text = forecastrain.toString()
                    curtempmaxView.text = cur_max.toString()
                    curtempminView.text = cur_min.toString()
                },
                com.android.volley.Response.ErrorListener {
                    println("******That didn't work!")
                    mainView.text = "Network Failure or City Not Exists"
                    nexttempmaxView.text = ""
                    nexttempminView.text = ""
                    nextrainView.text = ""
                }) {}
        // Add the request to the RequestQueue.
        queue.add(stringRequest)
        queue.add(stringRequest1)

    }

}

class WeatherResult(val id: Int, val name: String, val cod: Int, val coord: Coordinates, val main: WeatherMain, val weather: Array<Weather>)
class Coordinates(val lon: Double, val lat: Double)
class Weather(val main: String, val description: String, val icon: String)
class WeatherMain(val temp: Double, val temp_min: Double, val temp_max: Double, val pressure: Int, val humidity: Int)
class ForecastResult(val list: Array<ForecastWeather>, val city: City)
class City(val id: Int, val name: String, val timezone: Double)
class ForecastWeather(val main: WeatherMain, val rain: Rain, val dt_txt: String)
class Rain(@SerializedName("3h") val threehour: Double?, @SerializedName("1h") val onehour: Double?)
class EventDecorator implements DayViewDecorator {

    val color: Int
    var dates: HashSet<CalendarDay>

    fun EventDecorator(color: Int, dates: Collection<CalendarDay> ) {
        this.color = color;
        this.dates = HashSet<>(dates);
    }

    override fun shouldDecorate(day: CalendarDay): Boolean {
        return dates.contains(day);
    }

    override fun decorate(view: DayViewFacade) {
        view.addSpan(new DotSpan(5, color));
    }
}